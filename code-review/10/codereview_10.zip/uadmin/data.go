package uadmin

type listData struct {
	Rows  [][]interface{}
	Count int
}
