﻿

namespace mojoPortal.Business.Commerce
{
    public enum FulfillmentType
    {
        None = 3,
        Download = 1,
        PhysicalShipment = 2
    }
}
