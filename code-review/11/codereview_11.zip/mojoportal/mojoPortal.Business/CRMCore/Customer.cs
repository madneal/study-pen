﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mojoPortal.Business.CRMCore
{
    //schema ideas
    //http://www.databaseanswers.org/data_models/
    //http://www.databaseanswers.org/data_models/customers_and_campaigns_and_ecommerce/index.htm
    //http://www.databaseanswers.org/data_models/customers_and_addresses/index.htm

    // see also existing fields in web store

    class Customer
    {
    }
}
