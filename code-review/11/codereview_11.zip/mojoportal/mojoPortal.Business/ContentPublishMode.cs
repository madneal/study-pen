﻿
namespace mojoPortal.Business
{
    public enum ContentPublishMode
    {
        All = 0,
        WebOnly = 1,
        MobileOnly = 2
    }
}
