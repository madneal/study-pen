using System;

namespace mojoPortal.Business
{
	/// <summary>
	/// Summary description for TaskMonitor.
	/// </summary>
	public class TaskMonitor
	{
		public TaskMonitor()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
