### [Spark](http://sparkjava.com/) Authorization using [Jetty](https://www.eclipse.org/jetty/)'s BasicAuthenticator, DigestAuthenticator

    http://localhost:8080/hello/sameer // does'nt requires authorization
    http://localhost:8080/hello // does'nt requires authorization

    http://localhost:8080/auth/hello // requires authorization


 
