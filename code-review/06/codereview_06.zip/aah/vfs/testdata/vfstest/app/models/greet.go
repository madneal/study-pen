package models

// Greet holds the greeting message.
type Greet struct {
	Message string `json:"message"`
}
