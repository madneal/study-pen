package android.support.v7.view.menu;

public interface m {
  void a(f paramf);
  
  public static interface a {
    void a(h param1h, int param1Int);
    
    boolean a();
    
    h getItemData();
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/view/menu/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */