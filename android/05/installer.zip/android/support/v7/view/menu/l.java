package android.support.v7.view.menu;

import android.content.Context;

public interface l {
  void a(Context paramContext, f paramf);
  
  void a(f paramf, boolean paramBoolean);
  
  boolean a(f paramf, h paramh);
  
  boolean a(p paramp);
  
  void b(boolean paramBoolean);
  
  boolean b();
  
  boolean b(f paramf, h paramh);
  
  public static interface a {
    void a(f param1f, boolean param1Boolean);
    
    boolean a(f param1f);
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/view/menu/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */