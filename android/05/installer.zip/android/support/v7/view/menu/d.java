package android.support.v7.view.menu;

class d<T> extends Object {
  final T b;
  
  d(T paramT) {
    if (paramT == null)
      throw new IllegalArgumentException("Wrapped Object can not be null."); 
    this.b = paramT;
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/view/menu/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */