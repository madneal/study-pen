package android.support.v7.widget;

import android.support.v7.view.menu.l;
import android.view.Menu;
import android.view.Window;

public interface ab {
  void a(int paramInt);
  
  void a(Menu paramMenu, l.a parama);
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  boolean h();
  
  void i();
  
  void j();
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/widget/ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */