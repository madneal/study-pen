package android.support.v7.widget;

import android.content.res.Resources;
import android.widget.SpinnerAdapter;

public interface an extends SpinnerAdapter {
  Resources.Theme a();
  
  void a(Resources.Theme paramTheme);
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/widget/an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */