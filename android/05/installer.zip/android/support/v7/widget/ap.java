package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

class ap {
  public ColorStateList a;
  
  public PorterDuff.Mode b;
  
  public boolean c;
  
  public boolean d;
  
  void a() {
    this.a = null;
    this.d = false;
    this.b = null;
    this.c = false;
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/widget/ap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */