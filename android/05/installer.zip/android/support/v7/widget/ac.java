package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.h.au;
import android.support.v7.view.menu.f;
import android.support.v7.view.menu.l;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;

public interface ac {
  au a(int paramInt, long paramLong);
  
  ViewGroup a();
  
  void a(int paramInt);
  
  void a(Drawable paramDrawable);
  
  void a(l.a parama, f.a parama1);
  
  void a(ak paramak);
  
  void a(Menu paramMenu, l.a parama);
  
  void a(Window.Callback paramCallback);
  
  void a(CharSequence paramCharSequence);
  
  void a(boolean paramBoolean);
  
  Context b();
  
  void b(int paramInt);
  
  void b(boolean paramBoolean);
  
  void c(int paramInt);
  
  boolean c();
  
  void d();
  
  CharSequence e();
  
  void f();
  
  void g();
  
  boolean h();
  
  boolean i();
  
  boolean j();
  
  boolean k();
  
  boolean l();
  
  void m();
  
  void n();
  
  int o();
  
  int p();
  
  int q();
  
  Menu r();
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/widget/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */