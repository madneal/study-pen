package android.support.v7.widget;

import android.graphics.Rect;

public interface ae {
  void setOnFitSystemWindowsListener(a parama);
  
  public static interface a {
    void a(Rect param1Rect);
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/widget/ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */