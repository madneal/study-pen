package android.support.v7.b;

public final class a {
  public static final class a {
    public static final int actionBarDivider = 2130837504;
    
    public static final int actionBarItemBackground = 2130837505;
    
    public static final int actionBarPopupTheme = 2130837506;
    
    public static final int actionBarSize = 2130837507;
    
    public static final int actionBarSplitStyle = 2130837508;
    
    public static final int actionBarStyle = 2130837509;
    
    public static final int actionBarTabBarStyle = 2130837510;
    
    public static final int actionBarTabStyle = 2130837511;
    
    public static final int actionBarTabTextStyle = 2130837512;
    
    public static final int actionBarTheme = 2130837513;
    
    public static final int actionBarWidgetTheme = 2130837514;
    
    public static final int actionButtonStyle = 2130837515;
    
    public static final int actionDropDownStyle = 2130837516;
    
    public static final int actionLayout = 2130837517;
    
    public static final int actionMenuTextAppearance = 2130837518;
    
    public static final int actionMenuTextColor = 2130837519;
    
    public static final int actionModeBackground = 2130837520;
    
    public static final int actionModeCloseButtonStyle = 2130837521;
    
    public static final int actionModeCloseDrawable = 2130837522;
    
    public static final int actionModeCopyDrawable = 2130837523;
    
    public static final int actionModeCutDrawable = 2130837524;
    
    public static final int actionModeFindDrawable = 2130837525;
    
    public static final int actionModePasteDrawable = 2130837526;
    
    public static final int actionModePopupWindowStyle = 2130837527;
    
    public static final int actionModeSelectAllDrawable = 2130837528;
    
    public static final int actionModeShareDrawable = 2130837529;
    
    public static final int actionModeSplitBackground = 2130837530;
    
    public static final int actionModeStyle = 2130837531;
    
    public static final int actionModeWebSearchDrawable = 2130837532;
    
    public static final int actionOverflowButtonStyle = 2130837533;
    
    public static final int actionOverflowMenuStyle = 2130837534;
    
    public static final int actionProviderClass = 2130837535;
    
    public static final int actionViewClass = 2130837536;
    
    public static final int activityChooserViewStyle = 2130837537;
    
    public static final int alertDialogButtonGroupStyle = 2130837538;
    
    public static final int alertDialogCenterButtons = 2130837539;
    
    public static final int alertDialogStyle = 2130837540;
    
    public static final int alertDialogTheme = 2130837541;
    
    public static final int allowStacking = 2130837542;
    
    public static final int arrowHeadLength = 2130837543;
    
    public static final int arrowShaftLength = 2130837544;
    
    public static final int autoCompleteTextViewStyle = 2130837545;
    
    public static final int background = 2130837546;
    
    public static final int backgroundSplit = 2130837547;
    
    public static final int backgroundStacked = 2130837548;
    
    public static final int backgroundTint = 2130837549;
    
    public static final int backgroundTintMode = 2130837550;
    
    public static final int barLength = 2130837551;
    
    public static final int borderlessButtonStyle = 2130837552;
    
    public static final int buttonBarButtonStyle = 2130837553;
    
    public static final int buttonBarNegativeButtonStyle = 2130837554;
    
    public static final int buttonBarNeutralButtonStyle = 2130837555;
    
    public static final int buttonBarPositiveButtonStyle = 2130837556;
    
    public static final int buttonBarStyle = 2130837557;
    
    public static final int buttonPanelSideLayout = 2130837558;
    
    public static final int buttonStyle = 2130837559;
    
    public static final int buttonStyleSmall = 2130837560;
    
    public static final int buttonTint = 2130837561;
    
    public static final int buttonTintMode = 2130837562;
    
    public static final int checkboxStyle = 2130837563;
    
    public static final int checkedTextViewStyle = 2130837564;
    
    public static final int closeIcon = 2130837565;
    
    public static final int closeItemLayout = 2130837566;
    
    public static final int collapseContentDescription = 2130837567;
    
    public static final int collapseIcon = 2130837568;
    
    public static final int color = 2130837569;
    
    public static final int colorAccent = 2130837570;
    
    public static final int colorButtonNormal = 2130837571;
    
    public static final int colorControlActivated = 2130837572;
    
    public static final int colorControlHighlight = 2130837573;
    
    public static final int colorControlNormal = 2130837574;
    
    public static final int colorPrimary = 2130837575;
    
    public static final int colorPrimaryDark = 2130837576;
    
    public static final int colorSwitchThumbNormal = 2130837577;
    
    public static final int commitIcon = 2130837578;
    
    public static final int contentInsetEnd = 2130837579;
    
    public static final int contentInsetLeft = 2130837580;
    
    public static final int contentInsetRight = 2130837581;
    
    public static final int contentInsetStart = 2130837582;
    
    public static final int controlBackground = 2130837583;
    
    public static final int customNavigationLayout = 2130837584;
    
    public static final int defaultQueryHint = 2130837585;
    
    public static final int dialogPreferredPadding = 2130837586;
    
    public static final int dialogTheme = 2130837587;
    
    public static final int displayOptions = 2130837588;
    
    public static final int divider = 2130837589;
    
    public static final int dividerHorizontal = 2130837590;
    
    public static final int dividerPadding = 2130837591;
    
    public static final int dividerVertical = 2130837592;
    
    public static final int drawableSize = 2130837593;
    
    public static final int drawerArrowStyle = 2130837594;
    
    public static final int dropDownListViewStyle = 2130837595;
    
    public static final int dropdownListPreferredItemHeight = 2130837596;
    
    public static final int editTextBackground = 2130837597;
    
    public static final int editTextColor = 2130837598;
    
    public static final int editTextStyle = 2130837599;
    
    public static final int elevation = 2130837600;
    
    public static final int expandActivityOverflowButtonDrawable = 2130837601;
    
    public static final int gapBetweenBars = 2130837602;
    
    public static final int goIcon = 2130837603;
    
    public static final int height = 2130837604;
    
    public static final int hideOnContentScroll = 2130837605;
    
    public static final int homeAsUpIndicator = 2130837606;
    
    public static final int homeLayout = 2130837607;
    
    public static final int icon = 2130837608;
    
    public static final int iconifiedByDefault = 2130837609;
    
    public static final int imageButtonStyle = 2130837610;
    
    public static final int indeterminateProgressStyle = 2130837611;
    
    public static final int initialActivityCount = 2130837612;
    
    public static final int isLightTheme = 2130837613;
    
    public static final int itemPadding = 2130837614;
    
    public static final int layout = 2130837615;
    
    public static final int listChoiceBackgroundIndicator = 2130837616;
    
    public static final int listDividerAlertDialog = 2130837617;
    
    public static final int listItemLayout = 2130837618;
    
    public static final int listLayout = 2130837619;
    
    public static final int listPopupWindowStyle = 2130837620;
    
    public static final int listPreferredItemHeight = 2130837621;
    
    public static final int listPreferredItemHeightLarge = 2130837622;
    
    public static final int listPreferredItemHeightSmall = 2130837623;
    
    public static final int listPreferredItemPaddingLeft = 2130837624;
    
    public static final int listPreferredItemPaddingRight = 2130837625;
    
    public static final int logo = 2130837626;
    
    public static final int logoDescription = 2130837627;
    
    public static final int maxButtonHeight = 2130837628;
    
    public static final int measureWithLargestChild = 2130837629;
    
    public static final int multiChoiceItemLayout = 2130837630;
    
    public static final int navigationContentDescription = 2130837631;
    
    public static final int navigationIcon = 2130837632;
    
    public static final int navigationMode = 2130837633;
    
    public static final int overlapAnchor = 2130837634;
    
    public static final int paddingEnd = 2130837635;
    
    public static final int paddingStart = 2130837636;
    
    public static final int panelBackground = 2130837637;
    
    public static final int panelMenuListTheme = 2130837638;
    
    public static final int panelMenuListWidth = 2130837639;
    
    public static final int popupMenuStyle = 2130837640;
    
    public static final int popupTheme = 2130837641;
    
    public static final int popupWindowStyle = 2130837642;
    
    public static final int preserveIconSpacing = 2130837643;
    
    public static final int progressBarPadding = 2130837644;
    
    public static final int progressBarStyle = 2130837645;
    
    public static final int queryBackground = 2130837646;
    
    public static final int queryHint = 2130837647;
    
    public static final int radioButtonStyle = 2130837648;
    
    public static final int ratingBarStyle = 2130837649;
    
    public static final int ratingBarStyleIndicator = 2130837650;
    
    public static final int ratingBarStyleSmall = 2130837651;
    
    public static final int searchHintIcon = 2130837652;
    
    public static final int searchIcon = 2130837653;
    
    public static final int searchViewStyle = 2130837654;
    
    public static final int seekBarStyle = 2130837655;
    
    public static final int selectableItemBackground = 2130837656;
    
    public static final int selectableItemBackgroundBorderless = 2130837657;
    
    public static final int showAsAction = 2130837658;
    
    public static final int showDividers = 2130837659;
    
    public static final int showText = 2130837660;
    
    public static final int singleChoiceItemLayout = 2130837661;
    
    public static final int spinBars = 2130837662;
    
    public static final int spinnerDropDownItemStyle = 2130837663;
    
    public static final int spinnerStyle = 2130837664;
    
    public static final int splitTrack = 2130837665;
    
    public static final int srcCompat = 2130837666;
    
    public static final int state_above_anchor = 2130837667;
    
    public static final int submitBackground = 2130837668;
    
    public static final int subtitle = 2130837669;
    
    public static final int subtitleTextAppearance = 2130837670;
    
    public static final int subtitleTextColor = 2130837671;
    
    public static final int subtitleTextStyle = 2130837672;
    
    public static final int suggestionRowLayout = 2130837673;
    
    public static final int switchMinWidth = 2130837674;
    
    public static final int switchPadding = 2130837675;
    
    public static final int switchStyle = 2130837676;
    
    public static final int switchTextAppearance = 2130837677;
    
    public static final int textAllCaps = 2130837678;
    
    public static final int textAppearanceLargePopupMenu = 2130837679;
    
    public static final int textAppearanceListItem = 2130837680;
    
    public static final int textAppearanceListItemSmall = 2130837681;
    
    public static final int textAppearanceSearchResultSubtitle = 2130837682;
    
    public static final int textAppearanceSearchResultTitle = 2130837683;
    
    public static final int textAppearanceSmallPopupMenu = 2130837684;
    
    public static final int textColorAlertDialogListItem = 2130837685;
    
    public static final int textColorSearchUrl = 2130837686;
    
    public static final int theme = 2130837687;
    
    public static final int thickness = 2130837688;
    
    public static final int thumbTextPadding = 2130837689;
    
    public static final int title = 2130837690;
    
    public static final int titleMarginBottom = 2130837691;
    
    public static final int titleMarginEnd = 2130837692;
    
    public static final int titleMarginStart = 2130837693;
    
    public static final int titleMarginTop = 2130837694;
    
    public static final int titleMargins = 2130837695;
    
    public static final int titleTextAppearance = 2130837696;
    
    public static final int titleTextColor = 2130837697;
    
    public static final int titleTextStyle = 2130837698;
    
    public static final int toolbarNavigationButtonStyle = 2130837699;
    
    public static final int toolbarStyle = 2130837700;
    
    public static final int track = 2130837701;
    
    public static final int voiceIcon = 2130837702;
    
    public static final int windowActionBar = 2130837703;
    
    public static final int windowActionBarOverlay = 2130837704;
    
    public static final int windowActionModeOverlay = 2130837705;
    
    public static final int windowFixedHeightMajor = 2130837706;
    
    public static final int windowFixedHeightMinor = 2130837707;
    
    public static final int windowFixedWidthMajor = 2130837708;
    
    public static final int windowFixedWidthMinor = 2130837709;
    
    public static final int windowMinWidthMajor = 2130837710;
    
    public static final int windowMinWidthMinor = 2130837711;
    
    public static final int windowNoTitle = 2130837712;
  }
  
  public static final class b {
    public static final int abc_action_bar_embed_tabs = 2130903040;
    
    public static final int abc_action_bar_embed_tabs_pre_jb = 2130903041;
    
    public static final int abc_action_bar_expanded_action_views_exclusive = 2130903042;
    
    public static final int abc_allow_stacked_button_bar = 2130903043;
    
    public static final int abc_config_actionMenuItemAllCaps = 2130903044;
    
    public static final int abc_config_allowActionMenuItemTextWithIcon = 2130903045;
    
    public static final int abc_config_closeDialogWhenTouchOutside = 2130903046;
    
    public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 2130903047;
  }
  
  public static final class c {
    public static final int abc_background_cache_hint_selector_material_dark = 2130968576;
    
    public static final int abc_background_cache_hint_selector_material_light = 2130968577;
    
    public static final int abc_color_highlight_material = 2130968578;
    
    public static final int abc_input_method_navigation_guard = 2130968579;
    
    public static final int abc_primary_text_disable_only_material_dark = 2130968580;
    
    public static final int abc_primary_text_disable_only_material_light = 2130968581;
    
    public static final int abc_primary_text_material_dark = 2130968582;
    
    public static final int abc_primary_text_material_light = 2130968583;
    
    public static final int abc_search_url_text = 2130968584;
    
    public static final int abc_search_url_text_normal = 2130968585;
    
    public static final int abc_search_url_text_pressed = 2130968586;
    
    public static final int abc_search_url_text_selected = 2130968587;
    
    public static final int abc_secondary_text_material_dark = 2130968588;
    
    public static final int abc_secondary_text_material_light = 2130968589;
    
    public static final int accent_material_dark = 2130968590;
    
    public static final int accent_material_light = 2130968591;
    
    public static final int background_floating_material_dark = 2130968592;
    
    public static final int background_floating_material_light = 2130968593;
    
    public static final int background_material_dark = 2130968594;
    
    public static final int background_material_light = 2130968595;
    
    public static final int bright_foreground_disabled_material_dark = 2130968596;
    
    public static final int bright_foreground_disabled_material_light = 2130968597;
    
    public static final int bright_foreground_inverse_material_dark = 2130968598;
    
    public static final int bright_foreground_inverse_material_light = 2130968599;
    
    public static final int bright_foreground_material_dark = 2130968600;
    
    public static final int bright_foreground_material_light = 2130968601;
    
    public static final int button_material_dark = 2130968602;
    
    public static final int button_material_light = 2130968603;
    
    public static final int dim_foreground_disabled_material_dark = 2130968607;
    
    public static final int dim_foreground_disabled_material_light = 2130968608;
    
    public static final int dim_foreground_material_dark = 2130968609;
    
    public static final int dim_foreground_material_light = 2130968610;
    
    public static final int foreground_material_dark = 2130968611;
    
    public static final int foreground_material_light = 2130968612;
    
    public static final int highlighted_text_material_dark = 2130968613;
    
    public static final int highlighted_text_material_light = 2130968614;
    
    public static final int hint_foreground_material_dark = 2130968615;
    
    public static final int hint_foreground_material_light = 2130968616;
    
    public static final int material_blue_grey_800 = 2130968617;
    
    public static final int material_blue_grey_900 = 2130968618;
    
    public static final int material_blue_grey_950 = 2130968619;
    
    public static final int material_deep_teal_200 = 2130968620;
    
    public static final int material_deep_teal_500 = 2130968621;
    
    public static final int material_grey_100 = 2130968622;
    
    public static final int material_grey_300 = 2130968623;
    
    public static final int material_grey_50 = 2130968624;
    
    public static final int material_grey_600 = 2130968625;
    
    public static final int material_grey_800 = 2130968626;
    
    public static final int material_grey_850 = 2130968627;
    
    public static final int material_grey_900 = 2130968628;
    
    public static final int primary_dark_material_dark = 2130968629;
    
    public static final int primary_dark_material_light = 2130968630;
    
    public static final int primary_material_dark = 2130968631;
    
    public static final int primary_material_light = 2130968632;
    
    public static final int primary_text_default_material_dark = 2130968633;
    
    public static final int primary_text_default_material_light = 2130968634;
    
    public static final int primary_text_disabled_material_dark = 2130968635;
    
    public static final int primary_text_disabled_material_light = 2130968636;
    
    public static final int ripple_material_dark = 2130968637;
    
    public static final int ripple_material_light = 2130968638;
    
    public static final int secondary_text_default_material_dark = 2130968639;
    
    public static final int secondary_text_default_material_light = 2130968640;
    
    public static final int secondary_text_disabled_material_dark = 2130968641;
    
    public static final int secondary_text_disabled_material_light = 2130968642;
    
    public static final int switch_thumb_disabled_material_dark = 2130968643;
    
    public static final int switch_thumb_disabled_material_light = 2130968644;
    
    public static final int switch_thumb_material_dark = 2130968645;
    
    public static final int switch_thumb_material_light = 2130968646;
    
    public static final int switch_thumb_normal_material_dark = 2130968647;
    
    public static final int switch_thumb_normal_material_light = 2130968648;
  }
  
  public static final class d {
    public static final int abc_action_bar_content_inset_material = 2131034112;
    
    public static final int abc_action_bar_default_height_material = 2131034113;
    
    public static final int abc_action_bar_default_padding_end_material = 2131034114;
    
    public static final int abc_action_bar_default_padding_start_material = 2131034115;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131034116;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131034117;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131034118;
    
    public static final int abc_action_bar_progress_bar_size = 2131034119;
    
    public static final int abc_action_bar_stacked_max_height = 2131034120;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131034121;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131034122;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131034123;
    
    public static final int abc_action_button_min_height_material = 2131034124;
    
    public static final int abc_action_button_min_width_material = 2131034125;
    
    public static final int abc_action_button_min_width_overflow_material = 2131034126;
    
    public static final int abc_alert_dialog_button_bar_height = 2131034127;
    
    public static final int abc_button_inset_horizontal_material = 2131034128;
    
    public static final int abc_button_inset_vertical_material = 2131034129;
    
    public static final int abc_button_padding_horizontal_material = 2131034130;
    
    public static final int abc_button_padding_vertical_material = 2131034131;
    
    public static final int abc_config_prefDialogWidth = 2131034132;
    
    public static final int abc_control_corner_material = 2131034133;
    
    public static final int abc_control_inset_material = 2131034134;
    
    public static final int abc_control_padding_material = 2131034135;
    
    public static final int abc_dialog_fixed_height_major = 2131034136;
    
    public static final int abc_dialog_fixed_height_minor = 2131034137;
    
    public static final int abc_dialog_fixed_width_major = 2131034138;
    
    public static final int abc_dialog_fixed_width_minor = 2131034139;
    
    public static final int abc_dialog_list_padding_vertical_material = 2131034140;
    
    public static final int abc_dialog_min_width_major = 2131034141;
    
    public static final int abc_dialog_min_width_minor = 2131034142;
    
    public static final int abc_dialog_padding_material = 2131034143;
    
    public static final int abc_dialog_padding_top_material = 2131034144;
    
    public static final int abc_disabled_alpha_material_dark = 2131034145;
    
    public static final int abc_disabled_alpha_material_light = 2131034146;
    
    public static final int abc_dropdownitem_icon_width = 2131034147;
    
    public static final int abc_dropdownitem_text_padding_left = 2131034148;
    
    public static final int abc_dropdownitem_text_padding_right = 2131034149;
    
    public static final int abc_edit_text_inset_bottom_material = 2131034150;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131034151;
    
    public static final int abc_edit_text_inset_top_material = 2131034152;
    
    public static final int abc_floating_window_z = 2131034153;
    
    public static final int abc_list_item_padding_horizontal_material = 2131034154;
    
    public static final int abc_panel_menu_list_width = 2131034155;
    
    public static final int abc_search_view_preferred_width = 2131034156;
    
    public static final int abc_search_view_text_min_width = 2131034157;
    
    public static final int abc_seekbar_track_background_height_material = 2131034158;
    
    public static final int abc_seekbar_track_progress_height_material = 2131034159;
    
    public static final int abc_select_dialog_padding_start_material = 2131034160;
    
    public static final int abc_switch_padding = 2131034161;
    
    public static final int abc_text_size_body_1_material = 2131034162;
    
    public static final int abc_text_size_body_2_material = 2131034163;
    
    public static final int abc_text_size_button_material = 2131034164;
    
    public static final int abc_text_size_caption_material = 2131034165;
    
    public static final int abc_text_size_display_1_material = 2131034166;
    
    public static final int abc_text_size_display_2_material = 2131034167;
    
    public static final int abc_text_size_display_3_material = 2131034168;
    
    public static final int abc_text_size_display_4_material = 2131034169;
    
    public static final int abc_text_size_headline_material = 2131034170;
    
    public static final int abc_text_size_large_material = 2131034171;
    
    public static final int abc_text_size_medium_material = 2131034172;
    
    public static final int abc_text_size_menu_material = 2131034173;
    
    public static final int abc_text_size_small_material = 2131034174;
    
    public static final int abc_text_size_subhead_material = 2131034175;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131034176;
    
    public static final int abc_text_size_title_material = 2131034177;
    
    public static final int abc_text_size_title_material_toolbar = 2131034178;
    
    public static final int disabled_alpha_material_dark = 2131034181;
    
    public static final int disabled_alpha_material_light = 2131034182;
    
    public static final int highlight_alpha_material_colored = 2131034183;
    
    public static final int highlight_alpha_material_dark = 2131034184;
    
    public static final int highlight_alpha_material_light = 2131034185;
    
    public static final int notification_large_icon_height = 2131034186;
    
    public static final int notification_large_icon_width = 2131034187;
    
    public static final int notification_subtext_size = 2131034188;
  }
  
  public static final class e {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131099648;
    
    public static final int abc_action_bar_item_background_material = 2131099649;
    
    public static final int abc_btn_borderless_material = 2131099650;
    
    public static final int abc_btn_check_material = 2131099651;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131099652;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131099653;
    
    public static final int abc_btn_colored_material = 2131099654;
    
    public static final int abc_btn_default_mtrl_shape = 2131099655;
    
    public static final int abc_btn_radio_material = 2131099656;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131099657;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131099658;
    
    public static final int abc_btn_rating_star_off_mtrl_alpha = 2131099659;
    
    public static final int abc_btn_rating_star_on_mtrl_alpha = 2131099660;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131099661;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131099662;
    
    public static final int abc_cab_background_internal_bg = 2131099663;
    
    public static final int abc_cab_background_top_material = 2131099664;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131099665;
    
    public static final int abc_control_background_material = 2131099666;
    
    public static final int abc_dialog_material_background_dark = 2131099667;
    
    public static final int abc_dialog_material_background_light = 2131099668;
    
    public static final int abc_edit_text_material = 2131099669;
    
    public static final int abc_ic_ab_back_mtrl_am_alpha = 2131099670;
    
    public static final int abc_ic_clear_mtrl_alpha = 2131099671;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131099672;
    
    public static final int abc_ic_go_search_api_mtrl_alpha = 2131099673;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131099674;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131099675;
    
    public static final int abc_ic_menu_moreoverflow_mtrl_alpha = 2131099676;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131099677;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131099678;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131099679;
    
    public static final int abc_ic_search_api_mtrl_alpha = 2131099680;
    
    public static final int abc_ic_star_black_16dp = 2131099681;
    
    public static final int abc_ic_star_black_36dp = 2131099682;
    
    public static final int abc_ic_star_half_black_16dp = 2131099683;
    
    public static final int abc_ic_star_half_black_36dp = 2131099684;
    
    public static final int abc_ic_voice_search_api_mtrl_alpha = 2131099685;
    
    public static final int abc_item_background_holo_dark = 2131099686;
    
    public static final int abc_item_background_holo_light = 2131099687;
    
    public static final int abc_list_divider_mtrl_alpha = 2131099688;
    
    public static final int abc_list_focused_holo = 2131099689;
    
    public static final int abc_list_longpressed_holo = 2131099690;
    
    public static final int abc_list_pressed_holo_dark = 2131099691;
    
    public static final int abc_list_pressed_holo_light = 2131099692;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131099693;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131099694;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131099695;
    
    public static final int abc_list_selector_disabled_holo_light = 2131099696;
    
    public static final int abc_list_selector_holo_dark = 2131099697;
    
    public static final int abc_list_selector_holo_light = 2131099698;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131099699;
    
    public static final int abc_popup_background_mtrl_mult = 2131099700;
    
    public static final int abc_ratingbar_full_material = 2131099701;
    
    public static final int abc_ratingbar_indicator_material = 2131099702;
    
    public static final int abc_ratingbar_small_material = 2131099703;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131099704;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131099705;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131099706;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131099707;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131099708;
    
    public static final int abc_seekbar_thumb_material = 2131099709;
    
    public static final int abc_seekbar_track_material = 2131099710;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131099711;
    
    public static final int abc_spinner_textfield_background_material = 2131099712;
    
    public static final int abc_switch_thumb_material = 2131099713;
    
    public static final int abc_switch_track_mtrl_alpha = 2131099714;
    
    public static final int abc_tab_indicator_material = 2131099715;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131099716;
    
    public static final int abc_text_cursor_material = 2131099717;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131099718;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131099719;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131099720;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131099721;
    
    public static final int abc_textfield_search_material = 2131099722;
    
    public static final int notification_template_icon_bg = 2131099723;
  }
  
  public static final class f {
    public static final int action0 = 2131165184;
    
    public static final int action_bar = 2131165185;
    
    public static final int action_bar_activity_content = 2131165186;
    
    public static final int action_bar_container = 2131165187;
    
    public static final int action_bar_root = 2131165188;
    
    public static final int action_bar_spinner = 2131165189;
    
    public static final int action_bar_subtitle = 2131165190;
    
    public static final int action_bar_title = 2131165191;
    
    public static final int action_context_bar = 2131165192;
    
    public static final int action_divider = 2131165193;
    
    public static final int action_menu_divider = 2131165194;
    
    public static final int action_menu_presenter = 2131165195;
    
    public static final int action_mode_bar = 2131165196;
    
    public static final int action_mode_bar_stub = 2131165197;
    
    public static final int action_mode_close_button = 2131165198;
    
    public static final int activity_chooser_view_content = 2131165199;
    
    public static final int alertTitle = 2131165200;
    
    public static final int always = 2131165201;
    
    public static final int beginning = 2131165202;
    
    public static final int buttonPanel = 2131165203;
    
    public static final int cancel_action = 2131165204;
    
    public static final int checkbox = 2131165205;
    
    public static final int chronometer = 2131165206;
    
    public static final int collapseActionView = 2131165207;
    
    public static final int contentPanel = 2131165208;
    
    public static final int custom = 2131165209;
    
    public static final int customPanel = 2131165210;
    
    public static final int decor_content_parent = 2131165211;
    
    public static final int default_activity_button = 2131165212;
    
    public static final int disableHome = 2131165213;
    
    public static final int edit_query = 2131165214;
    
    public static final int end = 2131165215;
    
    public static final int end_padder = 2131165216;
    
    public static final int expand_activities_button = 2131165217;
    
    public static final int expanded_menu = 2131165218;
    
    public static final int home = 2131165219;
    
    public static final int homeAsUp = 2131165220;
    
    public static final int icon = 2131165221;
    
    public static final int ifRoom = 2131165222;
    
    public static final int image = 2131165223;
    
    public static final int info = 2131165224;
    
    public static final int line1 = 2131165225;
    
    public static final int line3 = 2131165226;
    
    public static final int listMode = 2131165227;
    
    public static final int list_item = 2131165228;
    
    public static final int media_actions = 2131165229;
    
    public static final int middle = 2131165231;
    
    public static final int multiply = 2131165232;
    
    public static final int never = 2131165233;
    
    public static final int none = 2131165234;
    
    public static final int normal = 2131165235;
    
    public static final int parentPanel = 2131165236;
    
    public static final int progress_circular = 2131165238;
    
    public static final int progress_horizontal = 2131165239;
    
    public static final int radio = 2131165240;
    
    public static final int screen = 2131165241;
    
    public static final int scrollIndicatorDown = 2131165242;
    
    public static final int scrollIndicatorUp = 2131165243;
    
    public static final int scrollView = 2131165244;
    
    public static final int search_badge = 2131165245;
    
    public static final int search_bar = 2131165246;
    
    public static final int search_button = 2131165247;
    
    public static final int search_close_btn = 2131165248;
    
    public static final int search_edit_frame = 2131165249;
    
    public static final int search_go_btn = 2131165250;
    
    public static final int search_mag_icon = 2131165251;
    
    public static final int search_plate = 2131165252;
    
    public static final int search_src_text = 2131165253;
    
    public static final int search_voice_btn = 2131165254;
    
    public static final int select_dialog_listview = 2131165255;
    
    public static final int shortcut = 2131165256;
    
    public static final int showCustom = 2131165257;
    
    public static final int showHome = 2131165258;
    
    public static final int showTitle = 2131165259;
    
    public static final int spacer = 2131165260;
    
    public static final int split_action_bar = 2131165261;
    
    public static final int src_atop = 2131165262;
    
    public static final int src_in = 2131165263;
    
    public static final int src_over = 2131165264;
    
    public static final int status_bar_latest_event_content = 2131165265;
    
    public static final int submit_area = 2131165267;
    
    public static final int tabMode = 2131165268;
    
    public static final int text = 2131165269;
    
    public static final int text2 = 2131165270;
    
    public static final int textSpacerNoButtons = 2131165271;
    
    public static final int time = 2131165272;
    
    public static final int title = 2131165273;
    
    public static final int title_template = 2131165274;
    
    public static final int topPanel = 2131165275;
    
    public static final int up = 2131165276;
    
    public static final int useLogo = 2131165277;
    
    public static final int withText = 2131165278;
    
    public static final int wrap_content = 2131165279;
  }
  
  public static final class g {
    public static final int abc_config_activityDefaultDur = 2131230720;
    
    public static final int abc_config_activityShortDur = 2131230721;
    
    public static final int abc_max_action_buttons = 2131230722;
    
    public static final int cancel_button_image_alpha = 2131230723;
    
    public static final int status_bar_notification_info_maxnum = 2131230724;
  }
  
  public static final class h {
    public static final int abc_action_bar_title_item = 2131296256;
    
    public static final int abc_action_bar_up_container = 2131296257;
    
    public static final int abc_action_bar_view_list_nav_layout = 2131296258;
    
    public static final int abc_action_menu_item_layout = 2131296259;
    
    public static final int abc_action_menu_layout = 2131296260;
    
    public static final int abc_action_mode_bar = 2131296261;
    
    public static final int abc_action_mode_close_item_material = 2131296262;
    
    public static final int abc_activity_chooser_view = 2131296263;
    
    public static final int abc_activity_chooser_view_list_item = 2131296264;
    
    public static final int abc_alert_dialog_button_bar_material = 2131296265;
    
    public static final int abc_alert_dialog_material = 2131296266;
    
    public static final int abc_dialog_title_material = 2131296267;
    
    public static final int abc_expanded_menu_layout = 2131296268;
    
    public static final int abc_list_menu_item_checkbox = 2131296269;
    
    public static final int abc_list_menu_item_icon = 2131296270;
    
    public static final int abc_list_menu_item_layout = 2131296271;
    
    public static final int abc_list_menu_item_radio = 2131296272;
    
    public static final int abc_popup_menu_item_layout = 2131296273;
    
    public static final int abc_screen_content_include = 2131296274;
    
    public static final int abc_screen_simple = 2131296275;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131296276;
    
    public static final int abc_screen_toolbar = 2131296277;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131296278;
    
    public static final int abc_search_view = 2131296279;
    
    public static final int abc_select_dialog_material = 2131296280;
    
    public static final int notification_media_action = 2131296283;
    
    public static final int notification_media_cancel_action = 2131296284;
    
    public static final int notification_template_big_media = 2131296285;
    
    public static final int notification_template_big_media_narrow = 2131296286;
    
    public static final int notification_template_lines = 2131296287;
    
    public static final int notification_template_media = 2131296288;
    
    public static final int notification_template_part_chronometer = 2131296289;
    
    public static final int notification_template_part_time = 2131296290;
    
    public static final int select_dialog_item_material = 2131296291;
    
    public static final int select_dialog_multichoice_material = 2131296292;
    
    public static final int select_dialog_singlechoice_material = 2131296293;
    
    public static final int support_simple_spinner_dropdown_item = 2131296294;
  }
  
  public static final class i {
    public static final int abc_action_bar_home_description = 2131427328;
    
    public static final int abc_action_bar_home_description_format = 2131427329;
    
    public static final int abc_action_bar_home_subtitle_description_format = 2131427330;
    
    public static final int abc_action_bar_up_description = 2131427331;
    
    public static final int abc_action_menu_overflow_description = 2131427332;
    
    public static final int abc_action_mode_done = 2131427333;
    
    public static final int abc_activity_chooser_view_see_all = 2131427334;
    
    public static final int abc_activitychooserview_choose_application = 2131427335;
    
    public static final int abc_capital_off = 2131427336;
    
    public static final int abc_capital_on = 2131427337;
    
    public static final int abc_search_hint = 2131427338;
    
    public static final int abc_searchview_description_clear = 2131427339;
    
    public static final int abc_searchview_description_query = 2131427340;
    
    public static final int abc_searchview_description_search = 2131427341;
    
    public static final int abc_searchview_description_submit = 2131427342;
    
    public static final int abc_searchview_description_voice = 2131427343;
    
    public static final int abc_shareactionprovider_share_with = 2131427344;
    
    public static final int abc_shareactionprovider_share_with_application = 2131427345;
    
    public static final int abc_toolbar_collapse_description = 2131427346;
    
    public static final int status_bar_notification_info_overflow = 2131427349;
  }
  
  public static final class j {
    public static final int AlertDialog_AppCompat = 2131492864;
    
    public static final int AlertDialog_AppCompat_Light = 2131492865;
    
    public static final int Animation_AppCompat_Dialog = 2131492866;
    
    public static final int Animation_AppCompat_DropDownUp = 2131492867;
    
    public static final int Base_AlertDialog_AppCompat = 2131492869;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131492870;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131492871;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131492872;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131492874;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131492873;
    
    public static final int Base_TextAppearance_AppCompat = 2131492875;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131492876;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131492877;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131492878;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131492879;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131492880;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131492881;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131492882;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131492883;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131492884;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131492885;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131492886;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131492887;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131492888;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131492889;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131492890;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131492891;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131492892;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131492893;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131492894;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131492895;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131492896;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131492897;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131492898;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131492899;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131492900;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131492901;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131492902;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131492903;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131492904;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131492905;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131492906;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131492907;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131492908;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131492909;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131492910;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131492911;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131492912;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131492913;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131492914;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131492915;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131492916;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131492917;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131492918;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131492933;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131492934;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131492935;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131492936;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131492937;
    
    public static final int Base_Theme_AppCompat = 2131492919;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131492920;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131492921;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131492925;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131492922;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131492923;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131492924;
    
    public static final int Base_Theme_AppCompat_Light = 2131492926;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131492927;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131492928;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131492932;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131492929;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131492930;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131492931;
    
    public static final int Base_V11_Theme_AppCompat_Dialog = 2131492938;
    
    public static final int Base_V11_Theme_AppCompat_Light_Dialog = 2131492939;
    
    public static final int Base_V12_Widget_AppCompat_AutoCompleteTextView = 2131492940;
    
    public static final int Base_V12_Widget_AppCompat_EditText = 2131492941;
    
    public static final int Base_V21_Theme_AppCompat = 2131492942;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131492943;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131492944;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131492945;
    
    public static final int Base_V22_Theme_AppCompat = 2131492946;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131492947;
    
    public static final int Base_V23_Theme_AppCompat = 2131492948;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131492949;
    
    public static final int Base_V7_Theme_AppCompat = 2131492950;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131492951;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131492952;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131492953;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131492954;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131492955;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131492956;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131492957;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131492958;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131492959;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131492960;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131492961;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131492962;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131492963;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131492964;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131492965;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131492966;
    
    public static final int Base_Widget_AppCompat_Button = 2131492967;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131492973;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131492974;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131492968;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131492969;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131492970;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131492971;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131492972;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131492975;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131492976;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131492977;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131492978;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131492979;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131492980;
    
    public static final int Base_Widget_AppCompat_EditText = 2131492981;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131492982;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131492983;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131492984;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131492985;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131492986;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131492987;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131492988;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131492989;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131492990;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131492991;
    
    public static final int Base_Widget_AppCompat_ListView = 2131492992;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131492993;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131492994;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131492995;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131492996;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131492997;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131492998;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131492999;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131493000;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131493001;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131493002;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131493003;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131493004;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131493005;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131493006;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131493007;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131493008;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131493009;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131493010;
    
    public static final int Platform_AppCompat = 2131493011;
    
    public static final int Platform_AppCompat_Light = 2131493012;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131493013;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131493014;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131493015;
    
    public static final int Platform_V11_AppCompat = 2131493016;
    
    public static final int Platform_V11_AppCompat_Light = 2131493017;
    
    public static final int Platform_V14_AppCompat = 2131493018;
    
    public static final int Platform_V14_AppCompat_Light = 2131493019;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131493020;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131493021;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131493022;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131493023;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131493024;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131493025;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131493026;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131493032;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131493027;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131493028;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131493029;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131493030;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131493031;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131493033;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131493034;
    
    public static final int TextAppearance_AppCompat = 2131493035;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131493036;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131493037;
    
    public static final int TextAppearance_AppCompat_Button = 2131493038;
    
    public static final int TextAppearance_AppCompat_Caption = 2131493039;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131493040;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131493041;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131493042;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131493043;
    
    public static final int TextAppearance_AppCompat_Headline = 2131493044;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131493045;
    
    public static final int TextAppearance_AppCompat_Large = 2131493046;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131493047;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131493048;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131493049;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131493050;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131493051;
    
    public static final int TextAppearance_AppCompat_Medium = 2131493052;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131493053;
    
    public static final int TextAppearance_AppCompat_Menu = 2131493054;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131493055;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131493056;
    
    public static final int TextAppearance_AppCompat_Small = 2131493057;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131493058;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131493059;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131493060;
    
    public static final int TextAppearance_AppCompat_Title = 2131493061;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131493062;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131493063;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131493064;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131493065;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131493066;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131493067;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131493068;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131493069;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131493070;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131493071;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131493072;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131493073;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131493074;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131493075;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131493076;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131493077;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131493078;
    
    public static final int TextAppearance_StatusBar_EventContent = 2131493079;
    
    public static final int TextAppearance_StatusBar_EventContent_Info = 2131493080;
    
    public static final int TextAppearance_StatusBar_EventContent_Line2 = 2131493081;
    
    public static final int TextAppearance_StatusBar_EventContent_Time = 2131493082;
    
    public static final int TextAppearance_StatusBar_EventContent_Title = 2131493083;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131493084;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131493085;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131493086;
    
    public static final int ThemeOverlay_AppCompat = 2131493108;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131493109;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131493110;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131493111;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131493112;
    
    public static final int Theme_AppCompat = 2131493087;
    
    public static final int Theme_AppCompat_CompactMenu = 2131493088;
    
    public static final int Theme_AppCompat_DayNight = 2131493089;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131493090;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131493091;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131493094;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131493092;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131493093;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131493095;
    
    public static final int Theme_AppCompat_Dialog = 2131493096;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131493099;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131493097;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131493098;
    
    public static final int Theme_AppCompat_Light = 2131493100;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131493101;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131493102;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131493105;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131493103;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131493104;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131493106;
    
    public static final int Theme_AppCompat_NoActionBar = 2131493107;
    
    public static final int Widget_AppCompat_ActionBar = 2131493113;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131493114;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131493115;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131493116;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131493117;
    
    public static final int Widget_AppCompat_ActionButton = 2131493118;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131493119;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131493120;
    
    public static final int Widget_AppCompat_ActionMode = 2131493121;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131493122;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131493123;
    
    public static final int Widget_AppCompat_Button = 2131493124;
    
    public static final int Widget_AppCompat_ButtonBar = 2131493130;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131493131;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131493125;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131493126;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131493127;
    
    public static final int Widget_AppCompat_Button_Colored = 2131493128;
    
    public static final int Widget_AppCompat_Button_Small = 2131493129;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131493132;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131493133;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131493134;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131493135;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131493136;
    
    public static final int Widget_AppCompat_EditText = 2131493137;
    
    public static final int Widget_AppCompat_ImageButton = 2131493138;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131493139;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131493140;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131493141;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131493142;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131493143;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131493144;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131493145;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131493146;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131493147;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131493148;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131493149;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131493150;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131493151;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131493152;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131493153;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131493154;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131493155;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131493156;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131493157;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131493158;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131493159;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131493160;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131493161;
    
    public static final int Widget_AppCompat_ListView = 2131493162;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131493163;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131493164;
    
    public static final int Widget_AppCompat_PopupMenu = 2131493165;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131493166;
    
    public static final int Widget_AppCompat_PopupWindow = 2131493167;
    
    public static final int Widget_AppCompat_ProgressBar = 2131493168;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131493169;
    
    public static final int Widget_AppCompat_RatingBar = 2131493170;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131493171;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131493172;
    
    public static final int Widget_AppCompat_SearchView = 2131493173;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131493174;
    
    public static final int Widget_AppCompat_SeekBar = 2131493175;
    
    public static final int Widget_AppCompat_Spinner = 2131493176;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131493177;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131493178;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131493179;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131493180;
    
    public static final int Widget_AppCompat_Toolbar = 2131493181;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131493182;
  }
  
  public static final class k {
    public static final int[] ActionBar = { 
        2130837546, 2130837547, 2130837548, 2130837579, 2130837580, 2130837581, 2130837582, 2130837584, 2130837588, 2130837589, 
        2130837600, 2130837604, 2130837605, 2130837606, 2130837607, 2130837608, 2130837611, 2130837614, 2130837626, 2130837633, 
        2130837641, 2130837644, 2130837645, 2130837669, 2130837672, 2130837690, 2130837698 };
    
    public static final int[] ActionBarLayout = { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetLeft = 4;
    
    public static final int ActionBar_contentInsetRight = 5;
    
    public static final int ActionBar_contentInsetStart = 6;
    
    public static final int ActionBar_customNavigationLayout = 7;
    
    public static final int ActionBar_displayOptions = 8;
    
    public static final int ActionBar_divider = 9;
    
    public static final int ActionBar_elevation = 10;
    
    public static final int ActionBar_height = 11;
    
    public static final int ActionBar_hideOnContentScroll = 12;
    
    public static final int ActionBar_homeAsUpIndicator = 13;
    
    public static final int ActionBar_homeLayout = 14;
    
    public static final int ActionBar_icon = 15;
    
    public static final int ActionBar_indeterminateProgressStyle = 16;
    
    public static final int ActionBar_itemPadding = 17;
    
    public static final int ActionBar_logo = 18;
    
    public static final int ActionBar_navigationMode = 19;
    
    public static final int ActionBar_popupTheme = 20;
    
    public static final int ActionBar_progressBarPadding = 21;
    
    public static final int ActionBar_progressBarStyle = 22;
    
    public static final int ActionBar_subtitle = 23;
    
    public static final int ActionBar_subtitleTextStyle = 24;
    
    public static final int ActionBar_title = 25;
    
    public static final int ActionBar_titleTextStyle = 26;
    
    public static final int[] ActionMenuItemView = { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = { 2130837546, 2130837547, 2130837566, 2130837604, 2130837672, 2130837698 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = { 2130837601, 2130837612 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = { 16842994, 2130837558, 2130837618, 2130837619, 2130837630, 2130837661 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonPanelSideLayout = 1;
    
    public static final int AlertDialog_listItemLayout = 2;
    
    public static final int AlertDialog_listLayout = 3;
    
    public static final int AlertDialog_multiChoiceItemLayout = 4;
    
    public static final int AlertDialog_singleChoiceItemLayout = 5;
    
    public static final int[] AppCompatImageView = { 16843033, 2130837666 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int[] AppCompatTextView = { 16842804, 2130837678 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_textAllCaps = 1;
    
    public static final int[] AppCompatTheme = { 
        16842839, 16842926, 2130837504, 2130837505, 2130837506, 2130837507, 2130837508, 2130837509, 2130837510, 2130837511, 
        2130837512, 2130837513, 2130837514, 2130837515, 2130837516, 2130837518, 2130837519, 2130837520, 2130837521, 2130837522, 
        2130837523, 2130837524, 2130837525, 2130837526, 2130837527, 2130837528, 2130837529, 2130837530, 2130837531, 2130837532, 
        2130837533, 2130837534, 2130837537, 2130837538, 2130837539, 2130837540, 2130837541, 2130837545, 2130837552, 2130837553, 
        2130837554, 2130837555, 2130837556, 2130837557, 2130837559, 2130837560, 2130837563, 2130837564, 2130837570, 2130837571, 
        2130837572, 2130837573, 2130837574, 2130837575, 2130837576, 2130837577, 2130837583, 2130837586, 2130837587, 2130837590, 
        2130837592, 2130837595, 2130837596, 2130837597, 2130837598, 2130837599, 2130837606, 2130837610, 2130837616, 2130837617, 
        2130837620, 2130837621, 2130837622, 2130837623, 2130837624, 2130837625, 2130837637, 2130837638, 2130837639, 2130837640, 
        2130837642, 2130837648, 2130837649, 2130837650, 2130837651, 2130837654, 2130837655, 2130837656, 2130837657, 2130837663, 
        2130837664, 2130837676, 2130837679, 2130837680, 2130837681, 2130837682, 2130837683, 2130837684, 2130837685, 2130837686, 
        2130837699, 2130837700, 2130837703, 2130837704, 2130837705, 2130837706, 2130837707, 2130837708, 2130837709, 2130837710, 
        2130837711, 2130837712 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorButtonNormal = 49;
    
    public static final int AppCompatTheme_colorControlActivated = 50;
    
    public static final int AppCompatTheme_colorControlHighlight = 51;
    
    public static final int AppCompatTheme_colorControlNormal = 52;
    
    public static final int AppCompatTheme_colorPrimary = 53;
    
    public static final int AppCompatTheme_colorPrimaryDark = 54;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 55;
    
    public static final int AppCompatTheme_controlBackground = 56;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 57;
    
    public static final int AppCompatTheme_dialogTheme = 58;
    
    public static final int AppCompatTheme_dividerHorizontal = 59;
    
    public static final int AppCompatTheme_dividerVertical = 60;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 61;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 62;
    
    public static final int AppCompatTheme_editTextBackground = 63;
    
    public static final int AppCompatTheme_editTextColor = 64;
    
    public static final int AppCompatTheme_editTextStyle = 65;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 66;
    
    public static final int AppCompatTheme_imageButtonStyle = 67;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 68;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 69;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 70;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 71;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 72;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 73;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 74;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 75;
    
    public static final int AppCompatTheme_panelBackground = 76;
    
    public static final int AppCompatTheme_panelMenuListTheme = 77;
    
    public static final int AppCompatTheme_panelMenuListWidth = 78;
    
    public static final int AppCompatTheme_popupMenuStyle = 79;
    
    public static final int AppCompatTheme_popupWindowStyle = 80;
    
    public static final int AppCompatTheme_radioButtonStyle = 81;
    
    public static final int AppCompatTheme_ratingBarStyle = 82;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 83;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 84;
    
    public static final int AppCompatTheme_searchViewStyle = 85;
    
    public static final int AppCompatTheme_seekBarStyle = 86;
    
    public static final int AppCompatTheme_selectableItemBackground = 87;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 88;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 89;
    
    public static final int AppCompatTheme_spinnerStyle = 90;
    
    public static final int AppCompatTheme_switchStyle = 91;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 92;
    
    public static final int AppCompatTheme_textAppearanceListItem = 93;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 94;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 95;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 96;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 97;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 98;
    
    public static final int AppCompatTheme_textColorSearchUrl = 99;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 100;
    
    public static final int AppCompatTheme_toolbarStyle = 101;
    
    public static final int AppCompatTheme_windowActionBar = 102;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 103;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 104;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 105;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 106;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 107;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 108;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 109;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 110;
    
    public static final int AppCompatTheme_windowNoTitle = 111;
    
    public static final int[] ButtonBarLayout = { 2130837542 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] CompoundButton = { 16843015, 2130837561, 2130837562 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonTint = 1;
    
    public static final int CompoundButton_buttonTintMode = 2;
    
    public static final int[] DrawerArrowToggle = { 2130837543, 2130837544, 2130837551, 2130837569, 2130837593, 2130837602, 2130837662, 2130837688 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] LinearLayoutCompat = { 16842927, 16842948, 16843046, 16843047, 16843048, 2130837589, 2130837591, 2130837629, 2130837659 };
    
    public static final int[] LinearLayoutCompat_Layout = { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130837517, 2130837535, 2130837536, 2130837658 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_showAsAction = 16;
    
    public static final int[] MenuView = { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130837643 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int[] PopupWindow = { 16843126, 2130837634 };
    
    public static final int[] PopupWindowBackgroundState = { 2130837667 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 1;
    
    public static final int[] SearchView = { 
        16842970, 16843039, 16843296, 16843364, 2130837565, 2130837578, 2130837585, 2130837603, 2130837609, 2130837615, 
        2130837646, 2130837647, 2130837652, 2130837653, 2130837668, 2130837673, 2130837702 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] Spinner = { 16842930, 16843126, 16843131, 16843362, 2130837641 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] SwitchCompat = { 16843044, 16843045, 16843074, 2130837660, 2130837665, 2130837674, 2130837675, 2130837677, 2130837689, 2130837701 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_track = 9;
    
    public static final int[] TextAppearance = { 16842901, 16842902, 16842903, 16842904, 16843105, 16843106, 16843107, 16843108, 2130837678 };
    
    public static final int TextAppearance_android_shadowColor = 4;
    
    public static final int TextAppearance_android_shadowDx = 5;
    
    public static final int TextAppearance_android_shadowDy = 6;
    
    public static final int TextAppearance_android_shadowRadius = 7;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_textAllCaps = 8;
    
    public static final int[] Toolbar = { 
        16842927, 16843072, 2130837567, 2130837568, 2130837579, 2130837580, 2130837581, 2130837582, 2130837626, 2130837627, 
        2130837628, 2130837631, 2130837632, 2130837641, 2130837669, 2130837670, 2130837671, 2130837690, 2130837691, 2130837692, 
        2130837693, 2130837694, 2130837695, 2130837696, 2130837697 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_collapseContentDescription = 2;
    
    public static final int Toolbar_collapseIcon = 3;
    
    public static final int Toolbar_contentInsetEnd = 4;
    
    public static final int Toolbar_contentInsetLeft = 5;
    
    public static final int Toolbar_contentInsetRight = 6;
    
    public static final int Toolbar_contentInsetStart = 7;
    
    public static final int Toolbar_logo = 8;
    
    public static final int Toolbar_logoDescription = 9;
    
    public static final int Toolbar_maxButtonHeight = 10;
    
    public static final int Toolbar_navigationContentDescription = 11;
    
    public static final int Toolbar_navigationIcon = 12;
    
    public static final int Toolbar_popupTheme = 13;
    
    public static final int Toolbar_subtitle = 14;
    
    public static final int Toolbar_subtitleTextAppearance = 15;
    
    public static final int Toolbar_subtitleTextColor = 16;
    
    public static final int Toolbar_title = 17;
    
    public static final int Toolbar_titleMarginBottom = 18;
    
    public static final int Toolbar_titleMarginEnd = 19;
    
    public static final int Toolbar_titleMarginStart = 20;
    
    public static final int Toolbar_titleMarginTop = 21;
    
    public static final int Toolbar_titleMargins = 22;
    
    public static final int Toolbar_titleTextAppearance = 23;
    
    public static final int Toolbar_titleTextColor = 24;
    
    public static final int[] View = { 16842752, 16842970, 2130837635, 2130837636, 2130837687 };
    
    public static final int[] ViewBackgroundHelper = { 16842964, 2130837549, 2130837550 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */