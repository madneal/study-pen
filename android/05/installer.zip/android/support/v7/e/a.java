package android.support.v7.e;

import android.view.ViewGroup;

public class a {
  public static void a(ViewGroup paramViewGroup) {}
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/e/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */