package android.support.v7.a;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.Window;

class h extends k {
  h(Context paramContext, Window paramWindow, e parame) { super(paramContext, paramWindow, parame); }
  
  View b(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) { return null; }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/a/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */