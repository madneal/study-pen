package android.support.v7.a;

import android.support.v7.view.b;

public interface e {
  b a(b.a parama);
  
  void a(b paramb);
  
  void b(b paramb);
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v7/a/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */