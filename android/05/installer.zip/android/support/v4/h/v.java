package android.support.v4.h;

import android.view.MotionEvent;

class v {
  static float a(MotionEvent paramMotionEvent, int paramInt) { return paramMotionEvent.getAxisValue(paramInt); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */