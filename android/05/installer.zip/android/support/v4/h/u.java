package android.support.v4.h;

import android.view.MotionEvent;

class u {
  public static int a(MotionEvent paramMotionEvent) { return paramMotionEvent.getSource(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */