package android.support.v4.h;

import android.view.ViewConfiguration;

class ar {
  static boolean a(ViewConfiguration paramViewConfiguration) { return paramViewConfiguration.hasPermanentMenuKey(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */