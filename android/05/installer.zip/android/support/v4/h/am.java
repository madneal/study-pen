package android.support.v4.h;

import android.view.View;

class am {
  public static int a(View paramView) { return paramView.getLayoutDirection(); }
  
  public static int b(View paramView) { return paramView.getWindowSystemUiVisibility(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/am.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */