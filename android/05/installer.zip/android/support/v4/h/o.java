package android.support.v4.h;

import android.view.ViewGroup;

class o {
  public static int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams) { return paramMarginLayoutParams.getMarginStart(); }
  
  public static int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams) { return paramMarginLayoutParams.getMarginEnd(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */