package android.support.v4.h;

import android.view.View;

public interface aa {
  bb a(View paramView, bb parambb);
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */