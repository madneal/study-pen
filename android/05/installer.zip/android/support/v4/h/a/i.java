package android.support.v4.h.a;

import android.view.accessibility.AccessibilityRecord;

class i {
  public static void a(Object paramObject, int paramInt) { ((AccessibilityRecord)paramObject).setScrollX(paramInt); }
  
  public static void a(Object paramObject, boolean paramBoolean) { ((AccessibilityRecord)paramObject).setScrollable(paramBoolean); }
  
  public static void b(Object paramObject, int paramInt) { ((AccessibilityRecord)paramObject).setScrollY(paramInt); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/a/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */