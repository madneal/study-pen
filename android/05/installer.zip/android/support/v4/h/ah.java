package android.support.v4.h;

import android.view.View;

class ah {
  public static int a(View paramView) { return paramView.getOverScrollMode(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */