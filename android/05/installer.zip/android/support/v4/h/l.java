package android.support.v4.h;

import android.view.LayoutInflater;

class l {
  static void a(LayoutInflater paramLayoutInflater, m paramm) {
    if (paramm != null) {
      k.a a = new k.a(paramm);
    } else {
      paramm = null;
    } 
    paramLayoutInflater.setFactory2(paramm);
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */