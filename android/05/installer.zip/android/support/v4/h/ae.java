package android.support.v4.h;

import android.view.VelocityTracker;

class ae {
  public static float a(VelocityTracker paramVelocityTracker, int paramInt) { return paramVelocityTracker.getYVelocity(paramInt); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */