package android.support.v4.h;

import android.view.View;

class aj {
  public static void a(View paramView, Object paramObject) { paramView.setAccessibilityDelegate((View.AccessibilityDelegate)paramObject); }
  
  public static boolean a(View paramView, int paramInt) { return paramView.canScrollVertically(paramInt); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/h/aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */