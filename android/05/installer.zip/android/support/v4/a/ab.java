package android.support.v4.a;

import android.util.AndroidRuntimeException;

final class ab extends AndroidRuntimeException {
  public ab(String paramString) { super(paramString); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/a/ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */