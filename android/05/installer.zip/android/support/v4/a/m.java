package android.support.v4.a;

import android.view.View;

public abstract class m {
  public abstract View a(int paramInt);
  
  public abstract boolean a();
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/a/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */