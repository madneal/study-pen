package android.support.v4.a;

import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class p {
  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  public abstract boolean a();
  
  public static interface a {
    void a();
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/a/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */