package android.support.v4.a;

import android.os.Bundle;
import android.support.v4.b.g;

public abstract class v {
  public boolean a() { return false; }
  
  public static interface a<D> {
    g<D> a(int param1Int, Bundle param1Bundle);
    
    void a(g<D> param1g);
    
    void a(g<D> param1g, D param1D);
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/a/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */