package android.support.v4.d.a;

import android.view.SubMenu;

public interface c extends a, SubMenu {}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/d/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */