package android.support.v4.b;

import android.content.ComponentName;
import android.content.Intent;

class f {
  public static Intent a(ComponentName paramComponentName) { return Intent.makeMainActivity(paramComponentName); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/b/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */