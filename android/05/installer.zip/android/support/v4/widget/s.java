package android.support.v4.widget;

import android.view.View;
import android.widget.PopupWindow;

class s {
  public static void a(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3) { paramPopupWindow.showAsDropDown(paramView, paramInt1, paramInt2, paramInt3); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/widget/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */