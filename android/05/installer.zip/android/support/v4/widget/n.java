package android.support.v4.widget;

import android.widget.ListView;

class n {
  static void a(ListView paramListView, int paramInt) { paramListView.scrollListBy(paramInt); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/widget/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */