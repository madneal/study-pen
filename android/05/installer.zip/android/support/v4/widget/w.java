package android.support.v4.widget;

import android.widget.OverScroller;

class w {
  public static float a(Object paramObject) { return ((OverScroller)paramObject).getCurrVelocity(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/widget/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */