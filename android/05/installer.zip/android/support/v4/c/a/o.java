package android.support.v4.c.a;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public interface o {
  void setTint(int paramInt);
  
  void setTintList(ColorStateList paramColorStateList);
  
  void setTintMode(PorterDuff.Mode paramMode);
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/c/a/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */