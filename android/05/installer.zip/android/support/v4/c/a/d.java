package android.support.v4.c.a;

import android.graphics.drawable.Drawable;

class d {
  public static Drawable a(Drawable paramDrawable) { return !(paramDrawable instanceof o) ? new k(paramDrawable) : paramDrawable; }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/c/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */