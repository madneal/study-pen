package android.support.v4.f;

import android.text.TextUtils;
import java.util.Locale;

class e {
  public static int a(Locale paramLocale) { return TextUtils.getLayoutDirectionFromLocale(paramLocale); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/android/support/v4/f/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */