package com.orm.a;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface d {
  String a() default "";
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/com/orm/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */