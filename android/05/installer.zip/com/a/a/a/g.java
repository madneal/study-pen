package com.a.a.a;

public abstract class g {
  private static final g a = new g() {
      public long a() { return e.a(); }
    };
  
  public static g b() { return a; }
  
  public abstract long a();
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/com/a/a/a/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */