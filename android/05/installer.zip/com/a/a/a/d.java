package com.a.a.a;

import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;

public final class d {
  @CheckReturnValue
  public static boolean a(@Nullable Object paramObject1, @Nullable Object paramObject2) { return (paramObject1 == paramObject2 || (paramObject1 != null && paramObject1.equals(paramObject2))); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/com/a/a/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */