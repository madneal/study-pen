package com.a.a.a;

final class e {
  static long a() { return System.nanoTime(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/com/a/a/a/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */