package com.a.a.b;

import java.util.ListIterator;

public abstract class j<E> extends i<E> implements ListIterator<E> {
  @Deprecated
  public final void add(E paramE) { throw new UnsupportedOperationException(); }
  
  @Deprecated
  public final void set(E paramE) { throw new UnsupportedOperationException(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/com/a/a/b/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */