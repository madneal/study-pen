package com.a.a.b;

import java.util.Iterator;

public abstract class i<E> extends Object implements Iterator<E> {
  @Deprecated
  public final void remove() { throw new UnsupportedOperationException(); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/com/a/a/b/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */