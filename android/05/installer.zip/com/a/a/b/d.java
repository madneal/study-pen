package com.a.a.b;

import com.a.a.a.c;

@Deprecated
abstract class d<K0, V0> extends Object {
  g.c<K0, V0> a;
  
  <K extends K0, V extends V0> g.c<K, V> a() { return (g.c)c.a(this.a, a.a); }
  
  enum a implements g.c<Object, Object> {
    a;
    
    public void a(g.d<Object, Object> param1d) {}
  }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/com/a/a/b/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */