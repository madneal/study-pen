package com.a.a.b;

import com.a.a.a.f;

final class c {
  static void a(boolean paramBoolean) { f.b(paramBoolean, "no calls to next() since the last call to remove()"); }
}


/* Location:              /Users/dongbing/project/study-pen/android/05/classes-dex2jar.jar!/com/a/a/b/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */